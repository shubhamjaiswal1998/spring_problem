package Injection1.injected;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InjectedApplicationTests {

	@Test
	void contextLoads() {
	}

}
